## v1.1.3 ##
- Fix:
  - Bug 53763 - [Counter][V1.1.2] Select counters,press "back"key, click"delete multiples"again,but counters still are selected.

## v1.1.2 ##
- Fix:
  - Bug 52835 - [Counter] Back button on ads inside list isn't returning to main page
  - Bug 52810 - [Counter][v1.1.1 ]no option to cancel "select all" ,after click to "select all"

## v1.1.1 ##
- Remove undesired rule to show banners in Counter List
- Update KaiAds to send languages to SSP
- Fix:
  - Bug 52488 - [Ads][V1.1.0] Delete item until where there's only one item, the ad disappear.
  - Bug 52466 - [V1.1.0]Click to"select all",then device is frozen or can't select all.
  - Bug 52464 - [ads][V1.1.0]The page doesn't show Ads at position 3+5n (n≥0) right away ,after create or delete

## v1.1.0 ##
- Update ads-adapter to include KaiAds
- Remove VMAX build variant

## v1.0.1 ##
- Add description in manifest.webapp (store requirement).

## v1.0.0 ##
- Adjustments in Web Manifest to send the application to the store.

## v0.8.0 ##
- Update ads-adapter;
- Update kscripts;
- Added command to generate build without ADS.

## v0.7.1 ##
- Translates improvements;
- Bug fixes: 47083.

## v0.7.0 ##
- Ads banner applied
- Bug-46843: There is no translation for Spanish-ES on GoFlip 1.0
- Bug-46986: Update counter is not working nor showing ad after select this option