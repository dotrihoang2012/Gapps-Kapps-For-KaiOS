const TAG = '[SERVICE WORKER]';
const appCacheVersion = 'wallpaper-cache-v0.5.8-f0';

const pattern = new RegExp('api/content/v1/file/', 'i');

const LISTENER_TYPE = {
  INSTALL: 'install',
  ACTIVATE: 'activate',
  FETCH: 'fetch'
};

self.addEventListener(LISTENER_TYPE.INSTALL, function(event) {});

self.addEventListener(LISTENER_TYPE.ACTIVATE, function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (appCacheVersion !== cacheName) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener(LISTENER_TYPE.FETCH, function(event) {
  const url = event.request.url;
  const cache = url.match(pattern);

  if (cache) {
    event.respondWith(
      caches.open(appCacheVersion).then(function(cache) {
        return cache
          .match(event.request, { ignoreSearch: true })
          .then(function(cacheResponse) {
            if (cacheResponse) {
              return cacheResponse;
            } else {
              return fetch(event.request).then(networkResponse => {
                console.log('service worker status', networkResponse.status);
                if (networkResponse.ok) {
                  const cloneetworkResponse = networkResponse.clone();
                  cache.put(event.request, cloneetworkResponse);
                }
                return networkResponse;
              });
            }
          });
      })
    );
  }
});
