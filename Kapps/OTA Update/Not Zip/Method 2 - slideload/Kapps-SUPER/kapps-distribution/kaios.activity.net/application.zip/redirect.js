const search = document.location.search;
const hasTokenCode = search.indexOf("code");
let code = "";
if (hasTokenCode !== -1) {
  const parts = search.split("&");
  parts.forEach(part => {
    if (part.startsWith("code")) {
      const codePart = part.split("=");
      code = codePart[1];
    }
  });
}
window.opener.postMessage(code, "*");
window.close();
