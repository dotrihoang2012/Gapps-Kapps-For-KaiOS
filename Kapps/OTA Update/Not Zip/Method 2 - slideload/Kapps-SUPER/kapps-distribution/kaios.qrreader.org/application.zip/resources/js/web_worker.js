self.importScripts('./jsQR.js');

self.onmessage = function(message){
  const data = message.data;
  const code = jsQR(data.data, data.width, data.height);
  if (code) {
    self.postMessage(code);
  }
};
