## 2.5.x - v1.6.4 && 3.x - 1.1.7

* Bug 135072 - Use mozCamera for 2.5.x and decode in child process.

## 2.5.x - v1.6.2 && 3.x - 1.1.5

* Bug 134910 - Add ja-JP and bump version for 2.5.x and 3.x.

## 2.5.x - v1.6.0 && 3.x - 1.1.1

* Remove take photo and implement real-time decode.

## 2.5.x - v1.5.18 3.x - 1.0.3

* Add cs-CZ,sk-SK translation for QR code reader

## 2.5.x - v1.5.14 3.x - 1.0.1

* Use ads loader instead of ads sdk in adapter

## v1.4.40

* Add timeout for ads loading

### v1.4.50
* Add ads-sdk v3

### v1.4.60
* Add related logic when scanning a text code

### v1.4.70
* bug fixed

### v1.4.80
* bug fixed

### v1.5.00
* Add scripts to compile next version on master branch.

### v1.5.01
* Bug fixed

### v1.5.02
* Bug fixed

### v1.5.03
* Add zh-HK and zh-TW translation for QR code reader

### v1.5.04
* Bug fixed

### v1.5.05
* Add permission declaration to meet China Type Approval requirement.

### v1.5.06
* Add vi-VN locale for QR reader.

### v1.5.08
* Add an ability to scan inverted(white on black) codes.

### v1.5.09
* Add hi-HI locale file for QR code reader.

### v1.5.10
* Add pl-PL locale file for QR code reader.

### v1.5.11
* Update pl-PL locale for QR code reader.

### v1.5.13
* Upgrade ads-adapter to 2.0.5.

### v1.5.15
* Update locales files for QR code reader.

### v1.5.16
* Add bg-BG locale files and app desc for QR code reader app.

### v1.5.17
* Add Amharic and Oromo locale files.

### v1.5.20
* Upgrade version for QR reader 2.5.
