## 2.5.x - 1.5.2

- Upgrade version for todo 2.5.

## 2.5.x - 1.5.0  3.x - 1.0.9

- [Localization] [Amharic] [Oromo] [am-ET] [om-ET] Add Amharic and Oromo locale files for To-Do.

## 2.5.x - 1.4.9  3.x - 1.0.8

- Change using ads-sdk to ads loader

## 1.4.6##

- Energizer E282SC project requires added ToDo APP multi-language.

## 1.4.5##

- In SFP version 3.0 add manifest.{lang}.webmanifest file for each country.
- Add locales files for To-Do.

## 1.4.4##

- Add ToDo locales for customer.

## 1.4.3##

- According to spec, the length limit should be added to the input, not the pop-up box.

## 1.4.2##

- Clear the default 'taskstore', which is useless, and no translation is provided in any language.

## 1.4.1##

- Add zh-TW locale for To-do.

## 1.4.0##

- Integration with new ads sdk v4.

## 1.3.9##

- Add zu-ZA locale for To-do.

## 1.3.8##

- Add vi-VN locale for To-do.

## 1.3.7##

- Modify permission declaration to meet China Type Approval requirement.

## 1.3.6##

- Fix the bug that the Todo application can't delete all lists.

## 1.3.5##

- Refactor l10n, upgrade kscripts and change l10n.ready to l10n.once.

## 1.3.4##

- [Language]['中文-简体']'New' on the homepage translates to '新建' & 'Select' translates to '选择'.
- [Language]["中文-简体"]On first entry, the default list "To-Do" should be translated.

## 1.3.3##

- Add scripts to compile next version on master branch.

## 1.3.2##

- Add Chinese support.

## 1.3.1##

- Reduce fullscreen ads launcher time to 5s.

## 1.3.0##

- Fix the incomplete display of j and g in the task page header.

## v1.0.7 ##

- Fix bug that would trigger the app's softkey when displaying ads after returning from Store
- Update KaiAds to v1.1.3 which now sends language settings to SSP

## v1.0.6 ##

- Remove KaiAds directly
- Remove ad capping on app side
- Add ads-adapter again, with support to updated KaiAds SDK and loading screen
- Fix bug-51928

## v1.0.5 ##

- Update KaiAds SDK with a new way to show ads thats works on all OEM devices.
- Bug fixed #51928.

## v1.0.4 ##

- Update KaiAds SDK with Seinlin's fix on iframe URL and date format issue.

## v1.0.3 ##

- Add KaiAds SDK support to advertise internal apps
- Show ads once every 3 times when opening a Task List

## v1.0.2 ##

- Add description in manifest.webapp

## v1.0.1 ##

- Change type of application to privileged

## v1.0.0 ##

- Initial version
