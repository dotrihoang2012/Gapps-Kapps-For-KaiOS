module.exports = function (api) {
  const isTest = api.env('test');
  const type = isTest ? 'auto' : 'false';

  const presets = [
    ["@babel/preset-env",
      {
        targets: {
          node: 'current',
        },
      },],
    "@babel/preset-react"
  ];
  const plugins = [
    "@babel/plugin-proposal-class-properties",
    "transform-es2015-modules-commonjs"
  ]

  return {
    presets,
    plugins
  };
}
