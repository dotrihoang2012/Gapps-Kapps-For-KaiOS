(function (i, s, o, g, r, a, m) {
  i['GoogleAnalyticsObject'] = r;
  (i[r] =
    i[r] ||
    function () {
      (i[r].q = i[r].q || []).push(arguments);
    }),
    (i[r].l = 1 * new Date());
  (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
  a.async = 1;
  a.src = g;
  m.parentNode.insertBefore(a, m);
})(
  window,
  document,
  'script',
  'https://www.google-analytics.com/analytics.js',
  'ga'
);

ga('create', 'G-RTRKTDXK51', { cookieDomain: 'none' });
ga('set', 'checkProtocolTask', function () {
  /* nothing */
});
ga('set', 'viewportSize', '240x320');
// must set location with "http", if use "app://". google analysis did not work
ga('set', 'location', 'http://127.0.0.1/');
ga('send', 'pageview');
