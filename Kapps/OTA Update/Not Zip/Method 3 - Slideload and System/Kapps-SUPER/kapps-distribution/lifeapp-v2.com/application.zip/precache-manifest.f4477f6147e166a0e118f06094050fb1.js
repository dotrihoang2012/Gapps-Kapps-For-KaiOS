self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e474b5e5b4339e0f9ff1fbdab360a4bd",
    "url": "/index.html"
  },
  {
    "revision": "73a8917dbe05af06d16e",
    "url": "/static/css/main.e00f1e4a.chunk.css"
  },
  {
    "revision": "05f3d8eed7ae4bf587d2",
    "url": "/static/js/2.62d645e8.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.62d645e8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "73a8917dbe05af06d16e",
    "url": "/static/js/main.d91db873.chunk.js"
  },
  {
    "revision": "1a3f3cda668949785213",
    "url": "/static/js/runtime-main.8e10f318.js"
  },
  {
    "revision": "1025a6e0fb0fa86f17f57cc82a6b9756",
    "url": "/static/media/OpenSans-Bold.1025a6e0.ttf"
  },
  {
    "revision": "3ed9575dcc488c3e3a5bd66620bdf5a4",
    "url": "/static/media/OpenSans-Regular.3ed9575d.ttf"
  },
  {
    "revision": "ba5cde21eeea0d57ab7efefc99596cce",
    "url": "/static/media/OpenSans-SemiBold.ba5cde21.ttf"
  },
  {
    "revision": "c4f5c45dc31be29a9e5305c29d6c2282",
    "url": "/static/media/agriculture.c4f5c45d.png"
  },
  {
    "revision": "69d18b6d34463f544206bcc875d9a56d",
    "url": "/static/media/articleNoInternet.69d18b6d.svg"
  },
  {
    "revision": "4f71a229a4d64f0552febd2270243df7",
    "url": "/static/media/checked.4f71a229.svg"
  },
  {
    "revision": "68c80ce91e248956990c6da49d027162",
    "url": "/static/media/covid-19.68c80ce9.png"
  },
  {
    "revision": "ee5e1aea167c26a4a8cbe4a6369024d6",
    "url": "/static/media/digital-literacy.ee5e1aea.png"
  },
  {
    "revision": "54647899327fd4aa23c34cb8e36ed938",
    "url": "/static/media/girls-women.54647899.png"
  },
  {
    "revision": "de912f44baadacc203e8b779603b66a6",
    "url": "/static/media/health.de912f44.png"
  },
  {
    "revision": "f86c0d3637a6be3792c0554f28076ddb",
    "url": "/static/media/kids-learning.f86c0d36.png"
  },
  {
    "revision": "a12e2d744a543d162486811293a3e52f",
    "url": "/static/media/life-app-icons.a12e2d74.ttf"
  },
  {
    "revision": "22991ee13d12630094a56a1398272790",
    "url": "/static/media/noSaved.22991ee1.svg"
  },
  {
    "revision": "77f0ea06878a00ff88d73f3b3bba6f0e",
    "url": "/static/media/search.77f0ea06.svg"
  },
  {
    "revision": "08b63c17c11b3c061174bba56f583e03",
    "url": "/static/media/upskilling.08b63c17.png"
  },
  {
    "revision": "d6c902675eeb1e7e92d46ab49603785f",
    "url": "/static/media/welcome.d6c90267.jpg"
  }
]);