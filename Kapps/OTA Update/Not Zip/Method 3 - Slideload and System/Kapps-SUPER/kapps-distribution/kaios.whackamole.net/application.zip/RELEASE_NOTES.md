v1.0.0
-------
 First release

 v1.0.1
-------
 - Copy file RELEASE_NOTES for package.
 - Update load sound.
 - Update file language.

 v1.0.2
-------
 - Update game description  in file manifest.
 - Bug 48001 - [Whack a mole][V1.0.1]In quit game screen,click cancel,the game screen is display black screen.
 - Update control sound.

 v1.0.3
-------
  - Update ADS-Adapter version 1.5.2.
  - Add loading screen while requesting ads.
  - Add ads on splash screen for vmax solution.

v1.0.4
-------
  - Update ads-adapter with new ads solution(kai) KaiAds from David SKY.
  - Remove VMAX as ads solution.

v1.0.5
-------
  - Fix bug that gameplay's softkey was triggered when displaying ads after returning from Store
  - Update KaiAds to v1.1.3 which now sends language settings to SSP
