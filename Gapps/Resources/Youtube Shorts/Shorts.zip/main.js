
// Opens the site in a remote browser frame, and close ourselves.
window.setTimeout(() => {
    window.open("https://youtube.com/shorts", '_blank');
    window.setTimeout(() => {
    window.close();
    }, 500);
}, 1000);